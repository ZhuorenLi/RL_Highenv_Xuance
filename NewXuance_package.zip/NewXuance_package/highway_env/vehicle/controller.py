from typing import List, Tuple, Union, Optional

import numpy as np
import copy
from highway_env import utils
from highway_env.road.road import Road, LaneIndex, Route
from highway_env.utils import Vector
from highway_env.vehicle.kinematics import Vehicle
from scipy import sparse
import math
import osqp



class ControlledVehicle(Vehicle):
    """
    A vehicle piloted by two low-level controller, allowing high-level actions such as cruise control and lane changes.

    - The longitudinal controller is a speed controller;
    - The lateral controller is a heading controller cascaded with a lateral position controller.
    """

    target_speed: float
    """ Desired velocity."""

    """Characteristic time"""
    TAU_ACC = 0.6  # [s]
    TAU_HEADING = 0.2  # [s]
    TAU_LATERAL = 0.6  # [s]

    TAU_PURSUIT = 0.5 * TAU_HEADING  # [s]
    KP_A = 1 / TAU_ACC
    KP_HEADING = 1 / TAU_HEADING
    KP_LATERAL = 1 / TAU_LATERAL  # [1/s]
    MAX_STEERING_ANGLE = np.pi / 6  # [rad]
    DELTA_SPEED = 1  # [m/s]

    MAX_ACC = 3  # [m/s^2]
    MAX_BRAKE_ACC = 3  # [m/s^2]
    Stanley_K = 0.5

    # HighD
    HISTORY_SIZE=45

    def __init__(self,
                 road: Road,
                 position: Vector,
                 heading: float = 0,
                 speed: float = 0,
                 target_lane_index: LaneIndex = None,
                 target_speed: float = None,
                 route: Route = None,
                 shape: [float, float] = [0, 0],
                 history_size: int = HISTORY_SIZE,
                 stp: int = -1, ):
        super().__init__(road, position, heading, speed)
        self.target_lane_index = target_lane_index or self.lane_index
        self.target_speed = target_speed or self.speed
        self.route = route
        self.steer_angle_filter = 0.0
        # 最小转弯半径
        self.R0 = self.LENGTH / (2 * math.sin(self.MAX_STEERING_ANGLE))
        self.using_CHDaction = False
        self.using_con_action = False

        self.action_type = None

        # HighD
        self.HD_traj=None
        self.stp=stp

    @classmethod
    def create_from(cls, vehicle: "ControlledVehicle") -> "ControlledVehicle":
        """
        Create a new vehicle from an existing one.

        The vehicle dynamics and target dynamics are copied, other properties are default.

        :param vehicle: a vehicle
        :return: a new vehicle at the same dynamical state
        """
        v = cls(vehicle.road, vehicle.position, heading=vehicle.heading, speed=vehicle.speed,
                target_lane_index=vehicle.target_lane_index, target_speed=vehicle.target_speed,
                route=vehicle.route)
        return v

    def plan_route_to(self, destination: str) -> "ControlledVehicle":
        """
        Plan a route to a destination in the road network

        :param destination: a node in the road network
        """
        try:
            path = self.road.network.shortest_path(self.lane_index[1], destination)
        except KeyError:
            path = []
        if path:
            self.route = [self.lane_index] + [(path[i], path[i + 1], None) for i in range(len(path) - 1)]
        else:
            self.route = [self.lane_index]
        return self

    def act(self, temp_action: Union[dict, str] = None) -> None:
        """
        Perform a high-level action to change the desired lane or speed.

        - If a high-level action is provided, update the target speed and lane;
        - then, perform longitudinal and lateral control.

        :param action: a high-level action
        """
        action = None
        if temp_action is not None and self.action_type is "Hybrid_Action":   # 离散动作空间:sac_CHD/p-dqn/MH3RL
            if temp_action[0] < 1:
                action = "LANE_LEFT"
            elif temp_action[0] >= 2:
                action = "LANE_RIGHT"
        else:
            action = temp_action
        self.follow_road()
        if self.action_type is not "Con_Action":
            if action == "FASTER":
                self.target_speed += self.DELTA_SPEED
            elif action == "SLOWER":
                self.target_speed -= self.DELTA_SPEED
            elif (action == "LANE_RIGHT") or (action == "RIGHT_1" or action == "RIGHT_2" or action == "RIGHT_3"):
                _from, _to, _id = self.target_lane_index
                target_lane_index = _from, _to, np.clip(_id + 1, 0, len(self.road.network.graph[_from][_to]) - 1)
                if self.road.network.get_lane(target_lane_index).is_reachable_from(self.position):
                    self.target_lane_index = target_lane_index
            elif (action == "LANE_LEFT") or (action == "LEFT_1" or action == "LEFT_2" or action == "LEFT_3"):
                _from, _to, _id = self.target_lane_index
                target_lane_index = _from, _to, np.clip(_id - 1, 0, len(self.road.network.graph[_from][_to]) - 1)
                if self.road.network.get_lane(target_lane_index).is_reachable_from(self.position):
                    self.target_lane_index = target_lane_index
        if self.predict_trajectory_primitive is not None:
            if self.action_type is "Dis_Action":   # 离散动作+轨迹基元，eg：DQN、sac_dis
                action = {"steering": self.steering_control_stanley(),
                          "acceleration": self.speed_control(self.target_speed)}
            elif temp_action is not None:        # sac_CHD, pdqn, MH3RL
                action = {"steering": self.steering_control_stanley(),
                          "acceleration": temp_action[2]}
            else:
                action = {"steering": self.steering_control_stanley(),
                          "acceleration": self.action['acceleration']}
        elif self.action_type is "Con_Action":  # sac_con
            if temp_action is not None:
                action = {"steering": temp_action[0], "acceleration": temp_action[1]}
            else:
                action = {"steering": self.action['steering'],
                          "acceleration": self.action['acceleration']}
        else:    # 无轨迹基元且不由agent直接控制时，由PID控制, ego:DQN
            action = {"steering": self.steering_control(self.target_lane_index),
                      "acceleration": self.speed_control(self.target_speed)}
        action['steering'] = np.clip(action['steering'], -self.MAX_STEERING_ANGLE, self.MAX_STEERING_ANGLE)
        action['acceleration'] = np.clip(action['acceleration'], -self.MAX_BRAKE_ACC, self.MAX_ACC)
        super().act(action)

    def follow_road(self) -> None:
        """At the end of a lane, automatically switch to a next one."""
        if self.road.network.get_lane(self.target_lane_index).after_end(self.position):
            self.target_lane_index = self.road.network.next_lane(self.target_lane_index,
                                                                 route=self.route,
                                                                 position=self.position,
                                                                 np_random=self.road.np_random)

    def steering_control(self, target_lane_index: LaneIndex) -> float:
        """
        Steer the vehicle to follow the center of an given lane.

        1. Lateral position is controlled by a proportional controller yielding a lateral speed command
        2. Lateral speed command is converted to a heading reference
        3. Heading is controlled by a proportional controller yielding a heading rate command
        4. Heading rate command is converted to a steering angle

        :param target_lane_index: index of the lane to follow
        :return: a steering wheel angle command [rad]
        """
        target_lane = self.road.network.get_lane(target_lane_index)
        lane_coords = target_lane.local_coordinates(self.position)
        lane_next_coords = lane_coords[0] + self.speed * self.TAU_PURSUIT
        lane_future_heading = target_lane.heading_at(lane_next_coords)

        # Lateral position control
        lateral_speed_command = - self.KP_LATERAL * lane_coords[1]
        # Lateral speed to heading
        heading_command = np.arcsin(np.clip(lateral_speed_command / utils.not_zero(self.speed), -1, 1))
        heading_ref = lane_future_heading + np.clip(heading_command, -np.pi/4, np.pi/4)
        # Heading control
        heading_rate_command = self.KP_HEADING * utils.wrap_to_pi(heading_ref - self.heading)
        # Heading rate to steering angle
        slip_angle = np.arcsin(np.clip(self.LENGTH / 2 / utils.not_zero(self.speed) * heading_rate_command, -1, 1))
        steering_angle = np.arctan(2 * np.tan(slip_angle))
        steering_angle = np.clip(steering_angle, -self.MAX_STEERING_ANGLE, self.MAX_STEERING_ANGLE)
        return float(steering_angle)

    def steering_control_test(self, target_lane_index: LaneIndex) -> float:
        """
        Steer the vehicle to follow the center of an given lane.
        引入基于OSQP的MPC

        1. Lateral position is controlled by a proportional controller yielding a lateral speed command
        2. Lateral speed command is converted to a heading reference
        3. Heading is controlled by a proportional controller yielding a heading rate command
        4. Heading rate command is converted to a steering angle

        :param target_lane_index: index of the lane to follow
        :return: a steering wheel angle command [rad]
        """
        target_lane = self.road.network.get_lane(target_lane_index)
        lane_coords = target_lane.local_coordinates(self.position)  # 距离起点的纵向与横向距离
        lane_next_coords = lane_coords[0] + self.speed * self.TAU_PURSUIT
        lane_future_heading = target_lane.heading_at(lane_next_coords)

        # Lateral position control
        lateral_speed_command = - self.KP_LATERAL * lane_coords[1]
        # Lateral speed to heading
        heading_command = np.arcsin(np.clip(lateral_speed_command / utils.not_zero(self.speed), -1, 1))
        heading_ref = lane_future_heading + np.clip(heading_command, -np.pi / 4, np.pi / 4)
        # Heading control
        heading_rate_command = self.KP_HEADING * utils.wrap_to_pi(heading_ref - self.heading)
        # Heading rate to steering angle
        steering_angle = np.arcsin(np.clip(self.LENGTH / 2 / utils.not_zero(self.speed) * heading_rate_command,
                                           -1, 1))
        steering_angle = np.clip(steering_angle, -self.MAX_STEERING_ANGLE, self.MAX_STEERING_ANGLE)

        init_l = lane_coords[1]
        init_yaw_error = utils.wrap_to_pi(lane_future_heading - self.heading)

        # print('init_l: ', "%.2f" % init_l)
        # print('init_yaw_error: ', init_yaw_error)

        Ad = sparse.csc_matrix([
            [1., 0.2],
            [0., 1.]
        ])
        Bd = sparse.csc_matrix([
            [0.],
            [0.2]])
        [nx, nu] = Bd.shape
        # print(nx)
        # print(nu)
        # Constraints
        u0 = 0.0
        umin = np.array([-0.03]) - u0
        umax = np.array([0.03]) - u0
        xmin = np.array([-10.0, -np.pi])
        xmax = np.array([10.0, np.pi])

        # Objective function
        Q = sparse.diags([10., 1.])
        QN = Q
        R = 5000 * sparse.eye(1)

        # Initial and reference states
        x0 = np.zeros(2)
        x0[0] = init_l
        x0[1] = init_yaw_error * -1.0
        xr = np.array([0.0, 0.])

        # Prediction horizon
        N = 500

        # Cast MPC problem to a QP: x = (x(0),x(1),...,x(N),u(0),...,u(N-1))
        # - quadratic objective
        P = sparse.block_diag([sparse.kron(sparse.eye(N), Q), QN,
                               sparse.kron(sparse.eye(N), R)], format='csc')
        # - linear objective
        q = np.hstack([np.kron(np.ones(N), -Q.dot(xr)), -QN.dot(xr),
                       np.zeros(N * nu)])
        # - linear dynamics
        Ax = sparse.kron(sparse.eye(N + 1), -sparse.eye(nx)) + sparse.kron(sparse.eye(N + 1, k=-1), Ad)
        Bu = sparse.kron(sparse.vstack([sparse.csc_matrix((1, N)), sparse.eye(N)]), Bd)
        Aeq = sparse.hstack([Ax, Bu])
        leq = np.hstack([-x0, np.zeros(N * nx)])
        ueq = leq
        # - input and state constraints
        Aineq = sparse.eye((N + 1) * nx + N * nu)
        lineq = np.hstack([np.kron(np.ones(N + 1), xmin), np.kron(np.ones(N), umin)])
        uineq = np.hstack([np.kron(np.ones(N + 1), xmax), np.kron(np.ones(N), umax)])
        # - OSQP constraints
        A = sparse.vstack([Aeq, Aineq], format='csc')
        l = np.hstack([leq, lineq])
        u = np.hstack([ueq, uineq])

        # Create an OSQP object
        prob = osqp.OSQP()

        # Setup workspace
        prob.setup(P, q, A, l, u, warm_start=True)
        res = prob.solve()

        # Check solver status
        if res.info.status != 'solved':
            raise ValueError('OSQP did not solve the problem!')
        control_cmd = np.zeros(nu * N);
        first_control = nx * (N + 1)
        for i in range(nu * N):
            control_cmd[i] = res.x[i + first_control]
        # print(control_cmd)
        # print(control_cmd[0])

        wheel_base = 2.5
        optimal_steering_angle = math.atan(wheel_base * control_cmd[1])
        # print('optimal_steering_angle: ', optimal_steering_angle)
        # print('steering_angle: ', steering_angle)
        self.steer_angle_filter = self.filter_angle(optimal_steering_angle, self.steer_angle_filter, 0.2)

        # print("steer_angle_filter: ", self.steer_angle_filter)
        steering_angle = optimal_steering_angle
        return float(steering_angle)

    def filter_angle(self, value, old_value, alfa) -> float:
        filter_value = value * alfa + (1 - alfa) * old_value
        return float(filter_value)

    def steering_control_stanley(self) -> float:

        target_lane = self.predict_trajectory_primitive
        nearest_point_index = self.get_nearest_point_index(target_lane)
        nearest_point_x = target_lane[nearest_point_index][0]
        nearest_point_y = target_lane[nearest_point_index][1]
        nearest_point_heading = self.predict_heading[nearest_point_index]
        # 计算横向误差
        if ((self.position[0]-nearest_point_x)*nearest_point_heading - (self.position[1]-nearest_point_y)) > 0:
            error = abs(np.sqrt((self.position[0]-nearest_point_x)**2 + (self.position[1]-nearest_point_y)**2))
        else:
            error = -abs(np.sqrt((self.position[0]-nearest_point_x)**2 + (self.position[1]-nearest_point_y)**2))

        steering_angle = nearest_point_heading - self.heading + math.atan2(self.Stanley_K * error, self.speed)
        steering_angle = np.clip(steering_angle, -self.MAX_STEERING_ANGLE, self.MAX_STEERING_ANGLE)

        return float(steering_angle)

    def get_nearest_point_index(self, target_lane):
        # 获取最近的轨迹点
        traj_point_x = np.zeros(len(target_lane), dtype=float)
        traj_point_y = np.zeros(len(target_lane), dtype=float)
        d = np.zeros(len(target_lane), dtype=float)
        for n in range(len(target_lane)):
            traj_point_x[n] = target_lane[n][0]
            traj_point_y[n] = target_lane[n][1]
        dx = self.position[0] - traj_point_x
        dy = self.position[1] - traj_point_y
        for i in range(len(traj_point_x)):
            d[i] = abs(np.sqrt(dx[i]**2 + dy[i]**2))
        index = list(d).index(min(d))
        return index

    def speed_control(self, target_speed: float) -> float:
        """
        Control the speed of the vehicle.

        Using a simple proportional controller.

        :param target_speed: the desired speed
        :return: an acceleration command [m/s2]
        """
        return self.KP_A * (target_speed - self.speed)

    def get_routes_at_intersection(self) -> List[Route]:
        """Get the list of routes that can be followed at the next intersection."""
        if not self.route:
            return []
        for index in range(min(len(self.route), 3)):
            try:
                next_destinations = self.road.network.graph[self.route[index][1]]
            except KeyError:
                continue
            if len(next_destinations) >= 2:
                break
        else:
            return [self.route]
        next_destinations_from = list(next_destinations.keys())
        routes = [self.route[0:index+1] + [(self.route[index][1], destination, self.route[index][2])]
                  for destination in next_destinations_from]
        return routes

    def set_route_at_intersection(self, _to: int) -> None:
        """
        Set the road to be followed at the next intersection.

        Erase current planned route.

        :param _to: index of the road to follow at next intersection, in the road network
        """

        routes = self.get_routes_at_intersection()
        if routes:
            if _to == "random":
                _to = self.road.np_random.randint(len(routes))
            self.route = routes[_to % len(routes)]

    def predict_trajectory_constant_speed(self, times: np.ndarray) -> Tuple[List[np.ndarray], List[float]]:
        """
        Predict the future positions of the vehicle along its planned route, under constant speed

        :param times: timesteps of prediction
        :return: positions, headings
        """
        coordinates = self.lane.local_coordinates(self.position)
        route = self.route or [self.lane_index]
        return tuple(zip(*[self.road.network.position_heading_along_route(route, coordinates[0] + self.speed * t, 0)
                     for t in times]))


class MDPVehicle(ControlledVehicle):

    """A controlled vehicle with a specified discrete range of allowed target speeds."""
    DEFAULT_TARGET_SPEEDS = np.linspace(0, 20, 10)
    # HighD
    HISTORY_SIZE=45

    def __init__(self,
                 road: Road,
                 position: List[float],
                 heading: float = 0,
                 speed: float = 0,
                 target_lane_index: Optional[LaneIndex] = None,
                 target_speed: Optional[float] = None,
                 target_speeds: Optional[Vector] = None,
                 route: Optional[Route] = None,
                 shape: [float, float] = [0, 0],
                 history_size:int=HISTORY_SIZE,
                 stp:int=-1,) -> None:
        """
        Initializes an MDPVehicle

        :param road: the road on which the vehicle is driving
        :param position: its position
        :param heading: its heading angle
        :param speed: its speed
        :param target_lane_index: the index of the lane it is following
        :param target_speed: the speed it is tracking
        :param target_speeds: the discrete list of speeds the vehicle is able to track, through faster/slower actions
        :param route: the planned route of the vehicle, to handle intersections
        """
        super().__init__(road, position, heading, speed, target_lane_index, target_speed, route)
        self.target_speeds = np.array(target_speeds) if target_speeds is not None else self.DEFAULT_TARGET_SPEEDS
        self.speed_index = self.speed_to_index(self.target_speed)
        self.target_speed = self.index_to_speed(self.speed_index)
        self.predict_trajectory_primitive = None
        self.predict_heading = None

    def act(self, action: Union[dict, str] = None) -> None:
        """
        Perform a high-level action.

        - If the action is a speed change, choose speed from the allowed discrete range.
        - Else, forward action to the ControlledVehicle handler.

        :param action: a high-level action
        """

        if isinstance(action, str) and action == "FASTER":
            self.speed_index = self.speed_to_index(self.speed) + 1
        elif isinstance(action, str) and action == "SLOWER":
            self.speed_index = self.speed_to_index(self.speed) - 1
        else:
            super().act(action)
            return
        self.speed_index = int(np.clip(self.speed_index, 0, self.target_speeds.size - 1))
        self.target_speed = self.index_to_speed(self.speed_index)
        super().act()

    def index_to_speed(self, index: int) -> float:
        """
        Convert an index among allowed speeds to its corresponding speed

        :param index: the speed index []
        :return: the corresponding speed [m/s]
        """
        return self.target_speeds[index]

    def speed_to_index(self, speed: float) -> int:
        """
        Find the index of the closest speed allowed to a given speed.

        Assumes a uniform list of target speeds to avoid searching for the closest target speed

        :param speed: an input speed [m/s]
        :return: the index of the closest speed allowed []
        """
        x = (speed - self.target_speeds[0]) / (self.target_speeds[-1] - self.target_speeds[0])
        return np.int64(np.clip(np.round(x * (self.target_speeds.size - 1)), 0, self.target_speeds.size - 1))

    @classmethod
    def speed_to_index_default(cls, speed: float) -> int:
        """
        Find the index of the closest speed allowed to a given speed.

        Assumes a uniform list of target speeds to avoid searching for the closest target speed

        :param speed: an input speed [m/s]
        :return: the index of the closest speed allowed []
        """
        x = (speed - cls.DEFAULT_TARGET_SPEEDS[0]) / (cls.DEFAULT_TARGET_SPEEDS[-1] - cls.DEFAULT_TARGET_SPEEDS[0])
        return np.int64(np.clip(
            np.round(x * (cls.DEFAULT_TARGET_SPEEDS.size - 1)), 0, cls.DEFAULT_TARGET_SPEEDS.size - 1))

    @classmethod
    def get_speed_index(cls, vehicle: Vehicle) -> int:
        return getattr(vehicle, "speed_index", cls.speed_to_index_default(vehicle.speed))

    def predict_trajectory(self, actions: List, action_duration: float, trajectory_timestep: float, dt: float) \
            -> List[ControlledVehicle]:
        """
        Predict the future trajectory of the vehicle given a sequence of actions.

        :param actions: a sequence of future actions.
        :param action_duration: the duration of each action.
        :param trajectory_timestep: the duration between each save of the vehicle state.
        :param dt: the timestep of the simulation
        :return: the sequence of future states
        """
        states = []
        v = copy.deepcopy(self)
        t = 0
        for action in actions:
            v.act(action)  # High-level decision
            for _ in range(int(action_duration / dt)):
                t += 1
                v.act()  # Low-level control action
                v.step(dt)
                if (t % int(trajectory_timestep / dt)) == 0:
                    states.append(copy.deepcopy(v))
        return states
