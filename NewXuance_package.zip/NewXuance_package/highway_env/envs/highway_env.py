from typing import Dict, Text, Tuple

import numpy as np
import random

from highway_env import utils
from highway_env.envs.common.abstract import AbstractEnv
from highway_env.envs.common.action import Action
from highway_env.road.road import Road, RoadNetwork
from highway_env.utils import near_split
from highway_env.vehicle.controller import ControlledVehicle
from highway_env.vehicle.kinematics import Vehicle

from high_d.src.highd_env_config import HighDEnvOption
from high_d.src.data_management.read_csv import *
import math

Observation = np.ndarray
# 0:初始场景
# 1：自定义三车道场景
SCENARIO_OPTION = 1

class HighwayEnv(AbstractEnv):
    """
    A highway driving environment.

    The vehicle is driving on a straight highway with several lanes, and is rewarded for reaching a high speed,
    staying on the rightmost lanes and avoiding collisions.
    """

    @classmethod
    def default_config(cls, action_type) -> dict:
        config = super().default_config()
        config.update({
            "observation": {
                "type": "Kinematics"
            },
            "action": {
                # "type": "DiscreteMetaAction",    # 离散动作(DQN, SAC_Dis)
                # "type": "ContHybridDiscAction",  # 连续离散混合动作(SAC_CHD, PPO_CHD)
                # "type":"ParameterizedAction",    # 参数化动作/连续离散混合动作(P-DQN)
                # "type": "MH3RL_Action",          # MH3RL架构下的动作空间
                # "type": "NewContinuousAction",   # 连续动作(SAC_Con, PPO_Con)
                "type": action_type,
            },
            "simulation_frequency": 5,  # 底层每秒仿真次数[Hz]
            "policy_frequency": 0.5,  # 底层每秒决策次数[Hz]
            "lanes_count": 3,
            "vehicles_count": 15,
            "controlled_vehicles": 1,
            "initial_lane_id": None,
            "duration": 200,  # [s]
            "ego_spacing": 2,
            "vehicles_density": 1,
            "V/C":0.4,
            "collision_reward": -5,    # 碰撞惩罚 The reward received when colliding with a vehicle.
            # "on_road_reward": 1,
            "right_lane_reward": 0,  # The reward received when driving on the right-most lanes, linearly mapped to
                                       # zero for other lanes.
            "high_speed_reward": 1,  # 高速奖励
            "low_speed_reward": -1,    # 低速惩罚
            "change_lane_reward": -0.1,   # 换道动作惩罚 The reward received at each lane change action.
            "acc_action_reward": -0.5,    # 加减速度惩罚
            "driving_steps_reward": 0,    # 回合长度奖励
            "ttc_front_reward": 0.1,    # 与前车的车头时距奖励
            "ttc_behind_reward": 0.05,    # 与后车的车头时距奖励
            "effect_vehicle_reward": 0,    # 影响周围车辆减速时的奖励
            "follow_lane_reward": 0,      # 车道偏离惩罚
            "reward_speed_range": [0, 20],   # 速度区间
            "expect_target_speed": 18,    # 期望速度
            "reward_low_speed_range": [0, 5],    # 低速惩罚区间
            "reward_ttc_front_range": [1.5, 5.0],
            "reward_ttc_behind_range": [1.5, 5.0],
            "normalize_reward": True,
            "offroad_terminal": True
        })
        if config['action']['type'] in ['DiscreteMetaAction', "NewDiscreteMetaAction"]:
            config.update({
                "acc_action_reward": -0.1,  # DQN, "FASTER/SLOWER"的惩罚
            })
        if config['action']['type'] == 'MH3RL_Action':
            config['policy_frequency'] = config['simulation_frequency']
        if config['action']['type'] == 'NewContinuousAction':
            config['policy_frequency'] = config['simulation_frequency']
            config.update({
                "change_lane_reward": -1,  # 离散换道->steer, 将steering相关惩罚扩大
                "follow_lane_reward": -0.5   # 车道偏离惩罚
            })
        return config

    def _reset(self) -> None:
        self._create_road()
        self._create_vehicles()

    def _create_road(self) -> None:
        """Create a road composed of straight adjacent lanes."""
        if SCENARIO_OPTION == 0:
            self.road = Road(network=RoadNetwork.straight_road_network(self.config["lanes_count"], speed_limit=30),
                             np_random=self.np_random, record_history=self.config["show_trajectories"])
        
        elif SCENARIO_OPTION != 0:
            self.road = Road(network=RoadNetwork.straight_road_network(self.config["lanes_count"], speed_limit= 18, nodes_str = ('a', 'b')),
                             np_random=self.np_random, record_history=self.config["show_trajectories"])

    def _create_vehicles(self) -> None:
        """Create some new random vehicles of a given type, and add them on the road."""
        other_vehicles_type = utils.class_from_path(self.config["other_vehicles_type"])
        other_per_controlled = near_split(self.config["vehicles_count"], num_bins=self.config["controlled_vehicles"])

        self.controlled_vehicles = []
        if SCENARIO_OPTION == 0:
            for others in other_per_controlled:
                vehicle = Vehicle.create_random(
                    self.road,
                    speed=25,
                    lane_id=self.config["initial_lane_id"],
                    spacing=self.config["ego_spacing"]
                )
                vehicle = self.action_type.vehicle_class(self.road, vehicle.position, vehicle.heading, vehicle.speed)
                self.controlled_vehicles.append(vehicle)
                self.road.vehicles.append(vehicle)

                for _ in range(others):
                    vehicle = other_vehicles_type.create_random(self.road, spacing=1 / self.config["vehicles_density"])
                    vehicle.randomize_behavior()
                    self.road.vehicles.append(vehicle)
        elif SCENARIO_OPTION == 1:
            D = random.randint(10, 30)
            lane_index = random.randint(0, self.config["lanes_count"] - 1)
            controlled_vehicle = Vehicle.make_on_lane(
                self.road,
                lane_index=('a', 'b', lane_index),
                longitudinal=D,
                speed=10
            )
            controlled_vehicle = self.action_type.vehicle_class(self.road, controlled_vehicle.position,\
                                                                controlled_vehicle.heading, controlled_vehicle.speed)
            self.controlled_vehicles.append(controlled_vehicle)
            self.road.vehicles.append(controlled_vehicle)
            other_per_controlled = near_split(self.config["vehicles_count"],
                                              num_bins=self.config["controlled_vehicles"])
            others = other_per_controlled[0]
            for lane in range(self.config["lanes_count"]):
                for _ in range(others):
                    vehicle = other_vehicles_type.create_random(self.road, lane_id=lane, spacing=1 / self.config["V/C"])
                    vehicle.randomize_behavior()
                    self.road.vehicles.append(vehicle)
                    is_exist = random.randint(1, self.config["lanes_count"])
                    if is_exist == 1 and _:
                        self.road.vehicles.pop(-2)


    def _reward(self, action: Action) -> float:
        """
        The reward is defined to foster driving at high speed, on the rightmost lanes, and to avoid collisions.
        :param action: the last action performed
        :return: the corresponding reward
        """
        rewards = self._rewards(action)
        reward = sum(self.config.get(name, 0) * reward for name, reward in rewards.items())
        # 单独评估安全性指标
        safety_reward = rewards["collision_reward"] * self.config["collision_reward"] + \
                        rewards["ttc_front_reward"] * self.config["ttc_front_reward"] + \
                        rewards["ttc_behind_reward"] * self.config["ttc_behind_reward"]

        if self.config["normalize_reward"]:
            reward = utils.lmap(reward, [self.config["collision_reward"] + self.config["low_speed_reward"]+\
                                         self.config["acc_action_reward"] + self.config["change_lane_reward"] + \
                                         self.config["follow_lane_reward"],
                                         self.config["high_speed_reward"] + self.config["right_lane_reward"] + \
                                         self.config["effect_vehicle_reward"] + self.config["driving_steps_reward"] +\
                                         2 * self.config["ttc_front_reward"] + 2 * self.config["ttc_behind_reward"]],
                                        [0, 1])
            safety_reward = utils.lmap(safety_reward, [self.config["collision_reward"], \
                                                       2 * self.config["ttc_front_reward"] + \
                                                       2 * self.config["ttc_behind_reward"]], \
                                                    [0, 1])
        reward *= rewards['on_road_reward']
        safety_reward *= rewards['on_road_reward']
        self.current_reward = reward
        self.current_safety_reward = safety_reward
        return reward, safety_reward

    def _rewards(self, action: Action) -> Dict[Text, float]:
        # neighbours = self.road.network.all_side_lanes(self.vehicle.lane_index)
        # lane = self.vehicle.target_lane_index[2] if isinstance(self.vehicle, ControlledVehicle) \
        #     else self.vehicle.lane_index[2]
        # # Use forward speed rather than speed, see https://github.com/eleurent/highway-env/issues/268
        # forward_speed = self.vehicle.speed * np.cos(self.vehicle.heading)
        # scaled_speed = utils.lmap(forward_speed, self.config["reward_speed_range"], [0, 1])
        
        front_veh_current, behind_veh_current = self.road.neighbour_vehicles(self.vehicle, self.vehicle.lane_index)
        front_veh_target, behind_veh_target = self.road.neighbour_vehicles(self.vehicle, self.vehicle.target_lane_index)
        scaled_ttc = 0
        if front_veh_current and ((self.vehicle.velocity[0] - front_veh_current.velocity[0]) > 0):
            delta_dis_cf = front_veh_current.position[0] - self.vehicle.position[
                0] - front_veh_current.LENGTH / 2 - self.vehicle.LENGTH / 2
            ttc_cf = delta_dis_cf / (self.vehicle.velocity[0] - front_veh_current.velocity[0])  # ttc_cf为与当前车道前方车辆预计相遇时间
        else:
            ttc_cf = self.config["reward_ttc_front_range"][1]
        if behind_veh_current and ((self.vehicle.velocity[0] - behind_veh_current.velocity[0]) < 0):
            delta_dis_cb = behind_veh_current.position[0] - self.vehicle.position[
                0] - behind_veh_current.LENGTH / 2 - self.vehicle.LENGTH / 2
            ttc_cb = delta_dis_cb / (
                        self.vehicle.velocity[0] - behind_veh_current.velocity[0])  # ttc_cb为与当前车道后方车辆预计相遇时间
        else:
            ttc_cb = self.config["reward_ttc_behind_range"][1]
        if front_veh_target and ((self.vehicle.velocity[0] - front_veh_target.velocity[0]) > 0):
            delta_dis_tf = front_veh_target.position[0] - self.vehicle.position[
                0] - front_veh_target.LENGTH / 2 - self.vehicle.LENGTH / 2
            ttc_tf = delta_dis_tf / abs(
                self.vehicle.velocity[0] - front_veh_target.velocity[0])  # ttc_tf为与目标车道前方车辆预计相遇时间
        else:
            ttc_tf = self.config["reward_ttc_front_range"][1]
        if behind_veh_target and ((self.vehicle.velocity[0] - behind_veh_target.velocity[0]) < 0):
            delta_dis_tb = behind_veh_target.position[0] - self.vehicle.position[
                0] - behind_veh_target.LENGTH / 2 - self.vehicle.LENGTH / 2
            ttc_tb = delta_dis_tb / abs(
                self.vehicle.velocity[0] - behind_veh_target.velocity[0])  # ttc_tb为与目标车道后方车辆预计相遇时间
        else:
            ttc_tb = self.config["reward_ttc_behind_range"][1]
        scaled_ttc_cf = utils.lmap(ttc_cf, self.config["reward_ttc_front_range"], [0, 1])
        scaled_ttc_cb = utils.lmap(ttc_cb, self.config["reward_ttc_behind_range"], [0, 1])
        scaled_ttc_tf = utils.lmap(ttc_tf, self.config["reward_ttc_front_range"], [0, 1])
        scaled_ttc_tb = utils.lmap(ttc_tb, self.config["reward_ttc_behind_range"], [0, 1])

        effect_VehiclesACC = 0
        # for k in range(1, len(self.road.vehicles)):  # 求影响周围车辆减速度的奖励
        #     if self.road.vehicles[k].action['acceleration'] < 0:
        #         effect_VehiclesACC += self.road.vehicles[k].action['acceleration']
        # scaled_effect_VehiclesACC = utils.lmap(abs(effect_VehiclesACC), [0, self.road.vehicles[k].ACC_MAX], [0, 1])

        # neighbours = self.road.network.all_side_lanes(self.vehicle.lane_index)
        # lane = self.vehicle.target_lane_index[2] if isinstance(self.vehicle, ControlledVehicle) \
        #     else self.vehicle.lane_index[2]    # 用于计算靠右行驶的奖励

        scaled_speed = utils.lmap(self.config["expect_target_speed"]-abs(self.vehicle.speed-self.config["expect_target_speed"]),\
                                  [0, self.config["expect_target_speed"]], [0, 1])    # 基于线性函数的高速奖励
        # scaled_speed = utils.lmap(
        #     (2 * self.config["expect_target_speed"] * self.vehicle.speed - self.vehicle.speed ** 2),
        #     [0, self.config["expect_target_speed"] ** 2], [0, 1])    # 基于二次函数的高速奖励

        low_speed_reward = 0   # 基于线性函数的低速惩罚
        if self.vehicle.speed < self.config["reward_low_speed_range"][1]:
            low_speed_reward = 1 - self.vehicle.speed / self.config["reward_low_speed_range"][1]

        acc_action_reward = 0
        change_lane_reward = 0
        if self.config["action"]["type"] == "ContHybridDiscAction":
            acc_action_reward = utils.lmap(abs(action[2]), [0,3], [0, 1])
            lane_change_action = action[0]
            if lane_change_action <= 1 or lane_change_action >= 2:
                change_lane_reward = 1
        elif self.config["action"]["type"] in ["ParameterizedAction","MH3RL_Action"]:
            if len(action) == 3:
                acc_action_reward = utils.lmap(abs(action[2]), [0, 3], [0, 1])
                if action[0] != 1:
                    change_lane_reward = 1
        elif self.config["action"]["type"] == "NewContinuousAction":
            change_lane_reward = utils.lmap(abs(action[0]), [0, np.pi / 6], [0, 1])
            acc_action_reward = utils.lmap(abs(action[1]), [0, 3], [0, 1])
        else:
            if self.action_type.actions[action] in ("FASTER", "SLOWER"):
                acc_action_reward = 1   # 加减速动作奖励
            elif self.action_type.actions[action] != "IDLE":
                change_lane_reward = 1    # 换道动作奖励

        follow_lane_reward = 0
        if self.config["action"]["type"] == "NewContinuousAction":
            current_lane_id = self.vehicle.lane_index[2]
            lane_width = self.road.network.graph['a']['b'][current_lane_id].DEFAULT_WIDTH
            nearest_lane_y = current_lane_id * lane_width
            distance_to_lane = abs(self.vehicle.position[1] - nearest_lane_y)
            follow_lane_reward = distance_to_lane/(lane_width/2)

        curent_steps = self.time / self.config["duration"]  # 回合长度奖励

        return {
            "collision_reward": float(self.vehicle.crashed),
            "high_speed_reward": np.clip(scaled_speed, 0, 1),
            "low_speed_reward": np.clip(low_speed_reward, 0, 1),
            "change_lane_reward": np.clip(change_lane_reward, 0, 1),
            "acc_action_reward": np.clip(acc_action_reward, 0, 1),
            "driving_steps_reward": np.clip(curent_steps, 0, 1),
            "ttc_front_reward": (np.clip(scaled_ttc_cf, 0, 1) + np.clip(scaled_ttc_tf, 0, 1)),
            "ttc_behind_reward": (np.clip(scaled_ttc_cb, 0, 1) + np.clip(scaled_ttc_tb, 0, 1)),
            "follow_lane_reward": np.clip(follow_lane_reward, 0, 1),
            # "right_lane_reward": lane / max(len(neighbours) - 1, 1),
            # "effect_vehicle_reward":np.clip(scaled_effect_VehiclesACC, 0, 1),
            "on_road_reward": float(self.vehicle.on_road)
        }
        

    def _is_terminated(self) -> bool:
        """The episode is over if the ego vehicle crashed."""
        return (self.vehicle.crashed or\
                self.config["offroad_terminal"] and not self.vehicle.on_road)

    def _is_truncated(self) -> bool:
        """The episode is truncated if the time limit is reached."""
        return self.time >= self.config["duration"]


class HighwayEnvFast(HighwayEnv):
    """
    A variant of highway-v0 with faster execution:
        - lower simulation frequency
        - fewer vehicles in the scene (and fewer lanes, shorter episode duration)
        - only check collision of controlled vehicles with others
    """
    @classmethod
    def default_config(cls) -> dict:
        cfg = super().default_config()
        cfg.update({
            "simulation_frequency": 5,
            "lanes_count": 3,
            "vehicles_count": 20,
            "duration": 30,  # [s]
            "ego_spacing": 1.5,
        })
        return cfg

    def _create_vehicles(self) -> None:
        super()._create_vehicles()
        # Disable collision check for uncontrolled vehicles
        for vehicle in self.road.vehicles:
            if vehicle not in self.controlled_vehicles:
                vehicle.check_collisions = False


class HighDEnv(HighwayEnv):
    """
    A highway driving environment.

    The vehicle is driving on a straight highway with several lanes, and is rewarded for reaching a high speed,
    staying on the rightmost lanes and avoiding collisions.
    """

    @classmethod
    def default_config(cls, action_type) -> dict:
        config = super().default_config(action_type)
        config.update({
            "show_trajectories": True,
            "simulation_frequency": 10,  # 25,#highd:25frames/s
            "other_vehicles_type": "highway_env.vehicle.behavior.IDMVehicle",
            "policy_frequency": 10,
        })
        if config['action']['type'] == 'NewContinuousAction':
            config['policy_frequency'] = config['simulation_frequency']
        return config

    def _init_high_d(self):
        if not self.config['using_only_init_HD']:
            self.config.update(
                {
                    'other_vehicles_type': "highway_env.vehicle.behavior.HighDAdjacentVehicle",
                }
            )
        self.Opt_HighD = HighDEnvOption(self.config['HD_configs'], int(self.config['HD_file_num_str']))
        self.current_veh_traj = self.Opt_HighD.get_tracks_by_id(self.config['track_id'])
        self.veh_config = self.Opt_HighD.get_static_info_by_id(self.config['track_id'])
        self.stp = self.get_steps()

    def _reset(self) -> None:
        self._init_high_d()
        assert self.current_veh_traj is not None, "current_veh_traj is None! Not INIT!!"
        self._create_road()
        self._create_vehicles()

    def _create_road(self) -> None:
        """Create a road composed of straight adjacent lanes."""
        lane_width = self.config['lane_width']
        self.road = Road(network=RoadNetwork.straight_road_network(self.config["lanes_count"],
                                                                   speed_limit=self.config["speed_limit"],
                                                                   nodes_str=('a', 'b'),
                                                                   length=460, width=lane_width,
                                                                   ),
                         np_random=self.np_random, record_history=self.config["show_trajectories"])
        # print('speed_lim:', self.config["speed_limit"])

    def _create_vehicles(self) -> None:
        """Create some new random vehicles of a given type, and add them on the road."""

        other_vehicles_type = utils.class_from_path(self.config["other_vehicles_type"])
        other_per_controlled = near_split(self.config["vehicles_count"], num_bins=self.config["controlled_vehicles"])
        self.controlled_vehicles = []
        self.stp = self.get_steps()
        # random_childscenario = random.randint(0, 9)
        speedx = self.current_veh_traj[X_VELOCITY][self.stp]
        speedy = self.current_veh_traj[Y_VELOCITY][self.stp]
        pos = np.array([self.current_veh_traj[X][self.stp], self.current_veh_traj[Y][self.stp]])
        heading = self.current_veh_traj[HEADING][self.stp]
        speed = math.hypot(speedx, speedy) / 3
        history_size = self.config["num_frames"]
        shape = [self.veh_config[WIDTH], self.veh_config[HEIGHT]]
        controlled_vehicle = Vehicle.HD_make_on_lane(
            self.road,
            position=pos,
            heading=heading,
            speed=speed,
            shape=shape,
            history_size=history_size,
        )
        if self.config['using_IDM_EV']:
            idm_type = utils.class_from_path("highway_env.vehicle.behavior.IDMVehicle")
            controlled_vehicle = idm_type(self.road, pos, speed=speed, target_speed=speed,
                                          enable_lane_change=True)
            controlled_vehicle.color = (50, 200, 0)
        else:
            controlled_vehicle = self.action_type.vehicle_class(self.road, pos,
                                                                heading, speed,
                                                                shape=shape, stp=self.stp, )
        controlled_vehicle.ego_HD_traj = self.current_veh_traj
        controlled_vehicle.ego_HD_config = self.veh_config
        # if self.config["is_pure_HD"]:
        #     controlled_vehicle.HD_traj=self.current_veh_traj
        self.controlled_vehicles.append(controlled_vehicle)
        self.road.vehicles.append(controlled_vehicle)
        # add close vehs by HD
        close_vehs = self.Opt_HighD.closed_vehicles(self.config['track_id'], self.stp, count=6
                                                    , ignore_none=True)

        for v in close_vehs:
            if v == None:
                continue
            pos = np.array([v[X][self.stp], v[Y][self.stp]])
            speed = math.hypot(v[X_VELOCITY][self.stp], v[Y_VELOCITY][self.stp])/3
            next_speed = math.hypot(v[X_VELOCITY][self.stp + 1], v[Y_VELOCITY][self.stp + 1])/3
            target_speed_v = round(max(v[X_VELOCITY]), 3)
            target_lane_index = v[LANE_ID][self.stp + 1]
            target_lane_index = ('a', 'b', target_lane_index)   # higdD correct
            shape = [v[WIDTH], v[HEIGHT]]
            other_veh = None
            if self.config['using_only_init_HD']:
                target_speed_v = random.randint(8, 12)
                other_veh = other_vehicles_type(self.road, pos, speed=speed, target_speed=target_speed_v,
                                                enable_lane_change=False, route=[('a', 'b', target_lane_index[2])],
                                                shape=shape)
            else:
                # print("----------using!! all HD!!")
                other_veh = other_vehicles_type(self.road, pos, speed=speed, next_speed=next_speed,
                                                target_lane_index=target_lane_index,
                                                enable_lane_change=True, shape=shape)

            other_veh.HD_traj = v
            self.road.vehicles.append(
                other_veh
            )

    # def _reward(self, action: Action) -> float:
    #     return super()._reward

    def _is_terminated(self) -> bool:
        """The episode is over if the ego vehicle crashed."""
        return (self.vehicle.crashed or
                self.config["offroad_terminal"] and not self.vehicle.on_road or
                # self.stp >= self.config["num_frames"] or
                self.vehicle.position[0] > self.road.network.graph['a']['b'][0].length)


    def step(self, action: Action) -> Tuple[Observation, float, bool, bool, dict]:
        """
        Perform an action and step the environment dynamics.

        The action is executed by the ego-vehicle, and all other vehicles on the road performs their default behaviour
        for several simulation timesteps until the next decision making step.

        :param action: the action performed by the ego-vehicle
        :return: a tuple (observation, reward, terminated, truncated, info)
        """
        if self.road is None or self.vehicle is None:
            raise NotImplementedError("The road and vehicle must be initialized in the environment implementation")

        self.time += 1 / self.config["policy_frequency"]
        if self.config['using_only_init_HD']:
            self._simulate(action)
        else:
            self._simulate_HD(action)
            
        obs = self.observation_type.observe()
        reward = self._reward(action)
        terminated = self._is_terminated()
        truncated = self._is_truncated()
        info = self._info(obs, action)
        if self.render_mode == 'human':
            self.render()
        return obs, reward, terminated, truncated, info

    # def _is_truncated(self) -> bool:
    #     """The episode is truncated if the time limit is reached."""
    #     return self.time >= self.config["duration"]

