from setuptools import find_packages, setup

setup(
    name='xuance',
    packages=find_packages(include=['xuance', 'xuance.*', 'highway_env', 'highway_env.*', 'high_d', 'highd.*']),
    package_data={
        "xuance":
            [
                "configs/*.yaml",
                "configs/*/*.yaml",
                "configs/*/*/*.yaml",
                "environment/magent2/libmagent.so",  # for magent2 environment on linux
                "environment/magent2/magent.dll",  # for magent2 environment on Windows
                "environment/magent2/libmagent.dylib"  # for magent2 environment on MacOS (for Intel CPU)
            ]
    },
    version="1.2.1",
    description='Project of RL based on XuanCe 1.2.1',
    author='Guizhe Jin',
    author_email='jgz13573016892@163.com',
    license='MIT',
    url='',
    download_url='https://github.com/agi-brain/xuance.git',
    keywords=['deep reinforcement learning', 'software library', 'PyTorch', 'TensorFlow2', 'MindSpore'],
    classifiers=[
        'Development Status :: 4 - Beta',
        # Chose either "3 - Alpha", "4 - Beta" or "5 - Production/Stable" as the current state of your package
        'Intended Audience :: Developers',  # Define that your audience are developers
        'Topic :: Software Development :: Build Tools',
        'License :: OSI Approved :: MIT License',  # Again, pick a license
        'Programming Language :: Python :: 3.6',  # Specify which python versions that you want to support
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
    ],
    install_requires=[
        "numpy>=1.21.6",
        "scipy==1.7.3",
        "PyYAML==6.0",  # default version is 6.0
        "gym==0.26.2",
        "gymnasium==0.28.1",
        "gym-notices==0.0.8",
        "mpi4py==3.1.3",
        "pygame==2.1.0",
        "tqdm==4.62.3",
        "pyglet==1.5.15",
        # "atari-py==0.2.9",
        # "ale-py==0.7.5",
        #"pettingzoo>=1.23.0",  # for MARL
        "tensorboard==2.11.2",  # logger
        "wandb==0.15.3",
        "moviepy==1.0.3",
        "imageio==2.9.0",  # default version is 2.9.0
        "opencv-python==4.5.4.58",
        "mpi4py==3.1.3",  # default version is 3.1.3
        "numpy==1.21.6",
        "osqp==0.6.3",
        "pygame==2.1.0",
        "pytest==7.1.2",
        "matplotlib==3.5.3",
        "pandas==1.3.5",
        "torch==1.13.1",
        "seaborn==0.12.2"
    ],
    setup_requires=['pytest-runner'],
    tests_requires=['pytest'],
    test_suite='tests',
)
