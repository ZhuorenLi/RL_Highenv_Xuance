import os,copy
import sys
import pickle
import argparse
from typing import List,Tuple,Union,Dict

from high_d.src.data_management.read_csv import *

Action = Union[int, np.ndarray]
Observation = Union[int, np.ndarray]

def create_args(file_id_str:str='01'):
    path0=os.path.dirname(os.path.abspath(__file__))
    path0+='/'
    parser = argparse.ArgumentParser(description="ParameterOptimizer")
    # --- Input paths ---
    parser.add_argument('--input_path', default=path0+"../data/{}_tracks.csv".format(file_id_str), type=str,
                        help='CSV file of the tracks')
    parser.add_argument('--input_static_path', default=path0+"../data/{}_tracksMeta.csv".format(file_id_str),
                        type=str,
                        help='Static meta data file for each track')
    parser.add_argument('--input_meta_path', default=path0+"../data/{}_recordingMeta.csv".format(file_id_str),
                        type=str,
                        help='Static meta data file for the whole video')
    parser.add_argument('--pickle_path', default=path0+"../data/{}.pickle".format(file_id_str), type=str,
                        help='Converted pickle file that contains corresponding information of the "input_path" file')
    # --- Settings ---
    parser.add_argument('--visualize', default=True, type=lambda x: (str(x).lower() == 'true'),
                        help='True if you want to visualize the data.')
    parser.add_argument('--background_image', default=path0+"../data/{}_highway.png".format(file_id_str), type=str,
                        help='Optional: you can specify the correlating background image.')

    # --- Visualization settings ---
    parser.add_argument('--plotBoundingBoxes', default=True, type=lambda x: (str(x).lower() == 'true'),
                        help='Optional: decide whether to plot the bounding boxes or not.')
    parser.add_argument('--plotDirectionTriangle', default=True, type=lambda x: (str(x).lower() == 'true'),
                        help='Optional: decide whether to plot the direction triangle or not.')
    parser.add_argument('--plotTextAnnotation', default=True, type=lambda x: (str(x).lower() == 'true'),
                        help='Optional: decide whether to plot the text annotation or not.')
    parser.add_argument('--plotTrackingLines', default=True, type=lambda x: (str(x).lower() == 'true'),
                        help='Optional: decide whether to plot the tracking lines or not.')
    parser.add_argument('--plotClass', default=True, type=lambda x: (str(x).lower() == 'true'),
                        help='Optional: decide whether to show the class in the text annotation.')
    parser.add_argument('--plotVelocity', default=True, type=lambda x: (str(x).lower() == 'true'),
                        help='Optional: decide whether to show the class in the text annotation.')
    parser.add_argument('--plotIDs', default=True, type=lambda x: (str(x).lower() == 'true'),
                        help='Optional: decide whether to show the class in the text annotation.')

    # --- I/O settings ---
    parser.add_argument('--save_as_pickle', default=True, type=lambda x: (str(x).lower() == 'true'),
                        help='Optional: you can save the tracks as pickle.')
    parsed_arguments = vars(parser.parse_args())
    return parsed_arguments

def getHighDInitConfigs(bg:int=1,ed:int=60,
                        accept_max_ttc:float=6,
                        accept_direction:int=2,
                        accept_lc_only:bool=True):
    '''
    read from all data files in [bg,ed] (bg,ed included )
    only accept the data with lane change and 0<ttc<=6 and direction==2
    :returns: HD_LC_configs:dict(
            'file_num':file_id,
            'file_num_str':file_num_str,
            'tracks_ids':using_track_ids,
            'tracks':lc_tracks,
            'static_infos':lc_static_info,
            'meta_info':meta_dictionary,
            'lanes_count':len(meta_dictionary[UPPER_LANE_MARKINGS]),
            'lane_width':round(np.mean(np.diff(meta_dictionary[UPPER_LANE_MARKINGS])),2),
            'first_lane_center':np.diff(meta_dictionary[UPPER_LANE_MARKINGS])[0],
            'speed_limit':meta_dictionary[SPEED_LIMIT],)
    '''
    HD_LC_configs={}
    
    for file_id in range(bg,ed+1):
        lc_tracks={}
        lc_static_info={}
        file_num_str='01'
        if file_id<10:
            file_num_str="0"+str(file_id)
        else:
            file_num_str=str(file_id)
        if file_num_str=='01':
            assert ( file_id==1),"didn't update file num id!! only support 01 now!!"
        created_arguments = create_args(file_num_str)
        print(" READ into file num: ",file_num_str)
        # print("Try to find the saved pickle file for better performance.")
        # Read the track csv and convert to useful format
        if os.path.exists(created_arguments["pickle_path"]):
            with open(created_arguments["pickle_path"], "rb") as fp:
                tracks = pickle.load(fp)
            print("Found pickle file {}.".format(created_arguments["pickle_path"]))
        else:
            print("Pickle file not found, csv will be imported now.")
            tracks = read_track_csv(created_arguments)
            print("Finished importing the pickle file.")

        if created_arguments["save_as_pickle"] and not os.path.exists(created_arguments["pickle_path"]):
            print("Save tracks to pickle file.")
            with open(created_arguments["pickle_path"], "wb") as fp:
                pickle.dump(tracks, fp)

        # Read the static info has interactive lane change
        try:
            static_info = read_static_info(created_arguments)
            using_track_ids=[]
            for t_id in static_info.keys():
                if static_info[t_id][MIN_TTC]<0 or static_info[t_id][MIN_TTC]>accept_max_ttc:
                    continue
                if accept_lc_only and static_info[t_id][NUMBER_LANE_CHANGES]<1:
                    continue
                if static_info[t_id][DRIVING_DIRECTION]!=accept_direction:
                    continue
                else:
                    assert t_id==static_info[t_id][TRACK_ID],"track id not match!!"
                    using_track_ids.append(t_id)
        except:
            print("The static info file is either missing or contains incorrect characters.")
            sys.exit(1)
        
        ids_around_vehs=[]
        import pdb
        pdb.set_trace
        for id in using_track_ids:
            oriens=[LEFT_PRECEDING_ID,PRECEDING_ID,RIGHT_PRECEDING_ID,
                    LEFT_FOLLOWING_ID,FOLLOWING_ID,RIGHT_FOLLOWING_ID]
            for der in oriens:
                for v_id in tracks[id][der]:
                    if v_id!=0 and v_id not in ids_around_vehs and v_id not in using_track_ids:
                        ids_around_vehs.append(v_id)
        # import pdb
        # pdb.set_trace()
        all_track_ids=ids_around_vehs+using_track_ids
        for id in all_track_ids:
            lc_tracks[id]=tracks[id]
            lc_static_info[id]=static_info[id]

        # Read the video meta
        try:
            meta_dictionary = read_meta_info(created_arguments)
        except:
            print("The video meta file is either missing or contains incorrect characters.")
            sys.exit(1)
        HD_LC_configs[file_id]={
            'file_num':file_id,
            'file_num_str':file_num_str,
            'tracks_ids':using_track_ids,
            'arround_ids':ids_around_vehs,
            'tracks':lc_tracks,
            'static_infos':lc_static_info,
            'meta_info':meta_dictionary,
            
            'lanes_count':len(meta_dictionary[LOWER_LANE_MARKINGS])-1,
            'lane_width':round(np.mean(np.diff(meta_dictionary[LOWER_LANE_MARKINGS])),2),
            'first_lane_center':np.round(0.5*((meta_dictionary[LOWER_LANE_MARKINGS])[0]+
                                         meta_dictionary[LOWER_LANE_MARKINGS][1]),1),
            'speed_limit':meta_dictionary[SPEED_LIMIT],
        }
        
    return HD_LC_configs


class HighDEnvOption():#highD deal function interface
    def __init__(self,HD_LC_configs:dict,
                 file_id:int=1,
                 need_trans_pos2highway:bool=True) -> None:
        config=HD_LC_configs[file_id]
        self.HD_config=config
        self.tracks=config['tracks']# need for highway_env reset
        self.static_info=config['static_infos']
        lanes_count=config['lanes_count']
        if need_trans_pos2highway:
            self.tracks=self.trans_pos2highway(self.tracks,lanes_count)
    
    def reset(self):
        obs = self.observation_type.observe()
        return obs

    def update_env(self):
        pass
    def get_tracks_by_id(self,track_id)->List:
        if track_id<=0:
            return None
        return self.tracks[track_id]
    def get_static_info_by_id(self,track_id)->List:
        if track_id<=0:
            return None
        return self.static_info[track_id]
            
    def get_x_distance_v22v1(self,v1,v2,id):
        return v2[X][id]-v1[X][id]
    
    def trans_pos2highway(self,tracks,lanes_count):
        for id_t in tracks.keys():
            track=tracks[id_t]
            for id in range(len(track[Y])):
                if track[LANE_ID][id] not in [4,5,6,7,8]:
                    continue
                track[LANE_ID][id]  = track[LANE_ID][id]-6 if lanes_count==3 else track[LANE_ID][id]-5
                track[Y][id]=track[Y][id]-self.HD_config['first_lane_center']+0.45*self.HD_config['lane_width']
                track[BBOX][id][1]=track[Y][id]
        return tracks
    
    def closed_vehicles(self,track_id,time_id, count: int = 6,
                          sort: bool = True,ignore_none=False) -> object:
        vehicle=self.get_tracks_by_id(track_id)
        frame=time_id+vehicle[FRAME][0]
        vehicles = [None] * count
        left_front_vehicles = self.get_tracks_by_id(vehicle[LEFT_PRECEDING_ID][time_id]) \
            if (int(vehicle[LEFT_PRECEDING_ID][time_id])!=0) else None
        same_front_vehicles = self.get_tracks_by_id(vehicle[PRECEDING_ID][time_id]) \
            if (int(vehicle[PRECEDING_ID][time_id])!=0) else None
        right_front_vehicles = self.get_tracks_by_id(vehicle[RIGHT_PRECEDING_ID][time_id]) \
            if (int(vehicle[RIGHT_PRECEDING_ID][time_id])!=0) else None
        left_behind_vehicles = self.get_tracks_by_id(vehicle[LEFT_FOLLOWING_ID][time_id]) \
            if (int(vehicle[LEFT_FOLLOWING_ID][time_id])!=0) else None
        same_behind_vehicles = self.get_tracks_by_id(vehicle[FOLLOWING_ID][time_id]) \
            if (int(vehicle[FOLLOWING_ID][time_id])!=0) else None
        right_behind_vehicles = self.get_tracks_by_id(vehicle[RIGHT_FOLLOWING_ID][time_id]) \
            if (int(vehicle[RIGHT_FOLLOWING_ID][time_id])!=0) else None
        
        vehicles[0] = left_front_vehicles
        vehicles[1] = same_front_vehicles
        vehicles[2] = right_front_vehicles
        vehicles[3] = left_behind_vehicles
        vehicles[4] = same_behind_vehicles
        vehicles[5] = right_behind_vehicles

        new_vehs=[]
        if ignore_none:
            for v in vehicles:
                if v==None:continue
                v_begin_id=frame-v[FRAME][0]
                assert v_begin_id>=0,("other veh didint exist now!!ID:",v[TRACK_ID])
                for key,val in v.items():
                    if isinstance(val,(np.float64,np.int64)):continue
                    if v_begin_id>=len(val):
                        continue
                    # new_v=copy.deepcopy(v)
                    v[key]=val[v_begin_id:]
                new_vehs.append(v) 
            vehicles=new_vehs
        if sort:
            vehicles = sorted(vehicles, key=lambda v: abs(v[X][time_id]-vehicle[X][time_id]))
        if count:
            vehicles = vehicles[:count]
        return vehicles
    
if __name__ == '__main__':
    conf=get_init_para_for_sb3()
    