from .data_management.read_csv import *
from .highd_env_config import getHighDInitConfigs, HighDEnvOption
from xuance.environment import make_envs


class HighD_Tester():
    def __init__(self, configs) -> None:
        self.configs = configs
        self.env_configs = None
            
    def getHighDEnvConfigs(self,
                           HD_config,
                           density=-1,
                           track_id=-1,
                           file_id=-1,
                           file_num_str='00',
                           test_low_speed=False,
                           vehicles_n=8,
                           args=None):
        file_tail = ''
        if not test_low_speed and density < 0:  # 主要使用这个分支
            file_tail = 'HD{}_id{}'.format(file_num_str, track_id)
            Opt_HighD = HighDEnvOption(HD_config, file_id=file_id)  # load HighD configuration file
            veh_config = Opt_HighD.get_static_info_by_id(track_id)
            init_frame = veh_config[INITIAL_FRAME]
            end_fram = veh_config[FINAL_FRAME]
            num_frames = veh_config[NUM_FRAMES]
            env_conf = {"config": {
                'HD_configs': HD_config,
                'HD_file_num_str': file_num_str,
                'using_only_init_HD': args.using_only_init_HD,
                'track_id': track_id,
                'render_mode': 'rgb_array',
                'density': density,
                "lanes_count": HD_config[file_id]['lanes_count'],
                'lane_width': HD_config[file_id]['lane_width'],
                'speed_limit': HD_config[file_id]['speed_limit'] if HD_config[file_id]['speed_limit'] > 0 else 40,
                "action": {
                    "type": self.configs.action_type,
                },
                'first_lane_center': HD_config[file_id]['first_lane_center'],
                'init_frame': init_frame,
                'end_fram': end_fram,
                'num_frames': num_frames,
                'is_pure_HD': args.is_pure_HD,
                'vehicles_count': vehicles_n,
                'using_IDM_EV': args.using_IDM_EV,
            }}
        elif track_id < 0:
            env_conf = {"config": {
                'render_mode': 'rgb_array',
                'density': density,
                'is_low_speed': test_low_speed,
                'vehicles_count': vehicles_n,
                'speed_limit': 20 if test_low_speed else 30,
            }}
            file_tail = 'dens{}'.format(density)
        assert file_tail != '', "EMPTY FILE TAIL!!"
        print('------------Test----config--------------')
        print("HD_file:", file_num_str)
        print("Track_id:", track_id)
        print('Density:', density)
        print('---------------------------------------')
        return env_conf
    
    
    def env_fn(self,):
        self.configs.parallels = 1
        return make_envs(self.configs, self.env_configs)
    
    def highD_test(self, Agent):
        # HighD prerequisite settings
        test_env_config = {}
        score_list = []
        highd_test_epsoides = 0
    
        try:
            for begin_file, end_file in zip([4, ], [10]):  # zip([1,11,21,31,41,51],[10,20,30,40,50,60]):
                HD_config = getHighDInitConfigs(begin_file, end_file)
    
                for file_id, file_conf in HD_config.items():
                    file_num_str = file_conf["file_num_str"]
                    test_env_config["track_ids"] = file_conf["tracks_ids"]
                    speed_limit = HD_config[file_id]['speed_limit']
    
                    for test_num, track_id in enumerate(test_env_config["track_ids"]):
                        # test数目达到预设测试episode上限或遍历完highd数据集后退出循环
                        if highd_test_epsoides >= self.configs.total_highd_test_episode:
                            raise BreakAllLoops

                        self.env_configs = self.getHighDEnvConfigs(HD_config=HD_config,
                                                                   file_num_str=file_num_str,
                                                                   file_id=file_id,
                                                                   track_id=track_id,
                                                                   test_low_speed=False,
                                                                   args=self.configs)
    
                        scores = Agent.test(self.env_fn, self.configs.test_episode, highd_test_epsoides)
                        highd_test_epsoides += 1
                        score_list.append(scores)  # 等待对score的进一步处理
        except BreakAllLoops:
            pass
    
    
class BreakAllLoops(Exception):
    pass