import numpy as np
from matplotlib import pyplot as plt, gridspec as gridspec
import seaborn as sns
import matplotlib as mpl
import matplotlib.cm as cm
import pygame
import torch


def remap(v, x, y, clip=False):
    if x[1] == x[0]:
        return y[0]
    out = y[0] + (v-x[0])*(y[1]-y[0])/(x[1]-x[0])
    if clip:
        out = constrain(out, y[0], y[1])
    return out
    
def constrain(x, a, b):
    return np.minimum(np.maximum(x, a), b)

class Graphics(object):
    """
        Graphical visualization
    """
    RED = (255, 0, 0)
    BLACK = (0, 0, 0)
    MIN_ATTENTION = 0.1

    @classmethod
    def display(cls, agent, surface, sim_surface=None, display_text=True):
        """
            Display the action-values for the current state

        :param agent: the Agent to be displayed
        :param surface: the pygame surface on which the agent is displayed
        :param sim_surface: the pygame surface on which the env is rendered
        :param display_text: whether to display the action values as text
        """

        cls.display_vehicles_attention(agent, sim_surface)

    @classmethod
    def display_vehicles_attention(cls, agent, sim_surface):
        try:
            state = agent.previous_state
            action = agent.previous_action
            if not agent.config.test or (agent.test_env is None and agent.config.test):
                unwrapped_env = agent.envs.envs[0].unwrapped.env
            else:
                unwrapped_env = agent.test_env
            if state is None or action is None:
                return

            if (not hasattr(cls, "state")) or (cls.state != state).any():
                cls.v_attention = cls.compute_vehicles_attention(agent, state, action)
                cls.state = state
                cls.action = action

            for head in range(list(cls.v_attention.values())[0].shape[0]):
                attention_surface = pygame.Surface(sim_surface.get_size(), pygame.SRCALPHA)
                for vehicle, attention in cls.v_attention.items():
                    if attention[head] < cls.MIN_ATTENTION:
                        continue
                    width = attention[head] * 5
                    desat = remap(attention[head], (0, 0.5), (0.7, 1), clip=True)
                    colors = sns.color_palette("dark", desat=desat)
                    color = np.array(colors[(2*head) % (len(colors) - 1)]) * 255
                    color = (*color, remap(attention[head], (0, 0.5), (100, 200), clip=True))
                    if vehicle is unwrapped_env.vehicle:
                        pygame.draw.circle(attention_surface, color,
                                           sim_surface.vec2pix(unwrapped_env.vehicle.position),
                                           max(sim_surface.pix(width / 2), 1))
                    else:
                        pygame.draw.line(attention_surface, color,
                                         sim_surface.vec2pix(unwrapped_env.vehicle.position),
                                         sim_surface.vec2pix(vehicle.position),
                                         max(sim_surface.pix(width), 1))
                sim_surface.blit(attention_surface, (0, 0))
        except ValueError as e:
            print("Unable to display vehicles attention", e)

    @classmethod
    def compute_vehicles_attention(cls, agent, state, action=None):
        state_t = torch.tensor(np.array([state]), dtype=torch.float).to(agent.device)
        # attention matrix size: [head, entities]
        if agent.config.agent == "Attn_SAC":
            if action is not None and agent.use_critic_attn_map:
                action_t = torch.tensor(np.array([action]), dtype=torch.float).view(-1, agent.action_dim).to(agent.device)
                attention = agent.policy.target_critic_1.ego_attention_net.get_attention_matrix(state_t, action_t).squeeze(0).squeeze(1).detach().cpu().numpy()
                ego, others, mask = agent.policy.target_critic_1.ego_attention_net.split_input(state_t, action_t)
            else:
                attention = agent.policy.actor.ego_attention_net.get_attention_matrix(state_t).squeeze(0).squeeze(1).detach().cpu().numpy()
                ego, others, mask = agent.policy.actor.ego_attention_net.split_input(state_t)
        elif agent.config.agent == "MultiCritic_Attention_MPDQN":
            if action is not None and agent.use_critic_attn_map:
                action_t = torch.tensor(np.array([action]), dtype=torch.float).view(-1, agent.action_dim).to(agent.device)
                attention = agent.policy.target_critic_1.ego_attention_net.get_attention_matrix(state_t, action_t).squeeze(0).squeeze(1).detach().cpu().numpy()
                ego, others, mask = agent.policy.target_critic_1.ego_attention_net.split_input(state_t, action_t)
            else:
                attention = agent.policy.conactor.ego_attention_net.get_attention_matrix(state_t).squeeze(0).squeeze(1).detach().cpu().numpy()
                ego, others, mask = agent.policy.conactor.ego_attention_net.split_input(state_t)
        elif agent.config.agent == "Attention_MPDQN":
            if action is not None and agent.use_critic_attn_map:
                action_t = torch.tensor(np.array([action]), dtype=torch.float).view(-1, agent.action_dim).to(agent.device)
                attention = agent.policy.qnetwork.ego_attention_net.get_attention_matrix(state_t, action_t).squeeze(0).squeeze(1).detach().cpu().numpy()
                ego, others, mask = agent.policy.qnetwork.ego_attention_net.split_input(state_t, action_t)
            else:
                attention = agent.policy.conactor.ego_attention_net.get_attention_matrix(state_t).squeeze(0).squeeze(1).detach().cpu().numpy()
                ego, others, mask = agent.policy.conactor.ego_attention_net.split_input(state_t)

        mask = mask.squeeze()
        v_attention = {}
        if not agent.config.test or (agent.test_env is None and agent.config.test):
            unwrapped_env = agent.envs.envs[0].unwrapped.env
        else:
            unwrapped_env = agent.test_env
        obs_type = unwrapped_env.observation_type
        if hasattr(obs_type, "agents_observation_types"):  # Handle multi-agent observation
            obs_type = obs_type.agents_observation_types[0]

        # iteration for each vehicle
        for v_index in range(state.shape[0]):
            if mask[v_index]:
                continue
            # get each vehicle's position
            v_position = {}
            for feature in ["x", "y"]:
                v_feature = state[v_index, obs_type.features.index(feature)]
                v_feature = remap(v_feature, [-1, 1], obs_type.features_range[feature])
                v_position[feature] = v_feature
            v_position = np.array([v_position["x"], v_position["y"]])
            if not obs_type.absolute and v_index > 0:
                v_position += unwrapped_env.unwrapped.vehicle.position

            # 根据车辆的y坐标区分车道ID，并将车辆添加入集合中； lane_idx: 0, 1, 2
            lane_center_positions = [0, 4, 8]
            lane_idx = np.argmin(np.abs(np.array(lane_center_positions) - v_position[1]))
            vehicle_list = []
            for v in unwrapped_env.road.vehicles:
                if lane_center_positions[lane_idx] - 2 <= v.position[1] and \
                   lane_center_positions[lane_idx] + 2 >= v.position[1]:
                    vehicle_list.append(v)

            # 基于欧式距离找到最近的车辆
            if vehicle_list is not None:
                vehicle = min(vehicle_list, key=lambda v: np.linalg.norm(v.position - v_position))
            else:
                vehicle = min(unwrapped_env.road.vehicles, key=lambda v: np.linalg.norm(v.position - v_position))

            vehicle = unwrapped_env.unwrapped.vehicle if v_index == 0 else vehicle
            v_attention[vehicle] = attention[:, v_index]
        return v_attention
