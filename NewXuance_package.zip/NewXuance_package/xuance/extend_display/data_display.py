import numpy as np
import matplotlib.pyplot as plt
import math
from highway_env import utils
import copy


class Data_Displayer(object):
    def __init__(self,
                 env = None,
                 rl_method = None
                 ):
        self.highway_env = env
        self.action_type = self.highway_env.config['action']['type']
        self.rl_method = rl_method

        self.fig, self.axs = plt.subplots(5, 1, figsize=(6,8))  # 创建5行1列的子图布局
        self.x_data = []
        self.y_data = [[] for _ in range(5)]
        for self.ax in self.axs:
            self.ax.set_xlim(0, 10)
        self.axs[0].set_ylim(0, 21)
        self.axs[1].set_ylim(-3.05, 3.05)
        self.axs[2].set_ylim(-1.05, 1.05)
        self.axs[3].set_ylim(-0.05, 1.05)
        self.axs[4].set_ylim(-0.6, 0.6)
        self.line1, = self.axs[0].plot(self.x_data, self.y_data[0], color='blue', label='vehicle_speed')
        self.line2, = self.axs[1].plot(self.x_data, self.y_data[1], color='red', label='vehicle_acc')
        self.line3, = self.axs[2].plot(self.x_data, self.y_data[2], color='yellow', label='trajectory_xd or steer')
        self.line4, = self.axs[3].plot(self.x_data, self.y_data[3], color='green', label='reward')
        self.line5, = self.axs[4].plot(self.x_data, self.y_data[4], color='blue', label='heading')
        self.text = self.axs[0].text(5, 0, '', fontsize=10, ha='center')
        # plt.pause(0.1)

    def HybridAct_instant_display_data(self, current_step, speed, heading, acc, lane_change_choice, xd, current_reward):
        while len(self.x_data) > 100:
            self.x_data.pop(0)  # 移除最早添加的元素
        for i in range(len(self.y_data)):
            while len(self.y_data[i]) > 100:
                self.y_data[i].pop(0)
        data = [speed, acc, xd, current_reward, heading]
        # 添加新数据点
        if isinstance(data[i], list):
            self.x_data += current_step   # 当数据为list
        else:
            self.x_data.append(current_step)    # 当数据为单个值
        for i in range(len(self.y_data)):
            if isinstance(data[i], list):
                self.y_data[i] += data[i]   # 当数据为list
            else:
                self.y_data[i].append(data[i])    # 当数据为单个值
        # 更新线条数据
        self.line1.set_data(self.x_data, self.y_data[0])
        self.line2.set_data(self.x_data, self.y_data[1])
        self.line3.set_data(self.x_data, self.y_data[2])
        self.line4.set_data(self.x_data, self.y_data[3])
        self.line5.set_data(self.x_data, self.y_data[4])

        # 动态调整x轴范围
        if isinstance(current_step, list):
            step_delta = current_step[1] - current_step[0]
            current_step = current_step[0]
            current_reward = current_reward[0]
        else:
            step_delta = 1
        for self.ax in self.axs:
            self.ax.set_xlim(max(0, current_step - 50*step_delta), max(50*step_delta, current_step))
        self.axs[0].set_ylabel('speed')
        self.axs[1].set_ylabel('acc')
        self.axs[2].set_ylabel('xd')
        self.axs[3].set_ylabel('reward')
        self.axs[4].set_ylabel('heading')
        if current_step > 40:
            if self.action_type in ["ContHybridDiscAction", "ParameterizedAction", "DiscreteMetaAction", "NewDiscreteMetaAction"]:
                self.text.set_text('Using method is: ' + self.rl_method +
                                   '\n chosen action is ' + lane_change_choice + \
                                   '. current reward is ' + str(float(current_reward)))
            elif self.action_type == "MH3RL_Action":
                self.text.set_text('Using method is: ' + self.rl_method +
                                   '\nchosen up_dis_action is ' + str(lane_change_choice) + \
                                   '. average reward is ' + str(float(current_reward)))
            self.text.set_position((current_step-25*step_delta, 25))
        if self.action_type in ["DiscreteMetaAction", "NewDiscreteMetaAction", "ParameterizedAction"]:
            plt.pause(0.001)

    def ConAct_instant_display_data(self, current_step, speed, heading, acc, steer, current_reward):
        while len(self.x_data) > 100:
            self.x_data.pop(0)  # 移除最早添加的元素
        for i in range(len(self.y_data)):
            while len(self.y_data[i]) > 100:
                self.y_data[i].pop(0)
        # 添加新数据点
        data = [speed, acc, steer, current_reward, heading]
        self.x_data.append(current_step)
        for i in range(len(self.y_data)):
            self.y_data[i].append(data[i])    # 当数据为单个值
        # 更新线条数据
        self.line1.set_data(self.x_data, self.y_data[0])
        self.line2.set_data(self.x_data, self.y_data[1])
        self.line3.set_data(self.x_data, self.y_data[2])
        self.line4.set_data(self.x_data, self.y_data[3])
        self.line5.set_data(self.x_data, self.y_data[4])
        # 动态调整x轴范围
        for self.ax in self.axs:
            self.ax.set_xlim(max(0, current_step - 50), max(50, current_step))
        self.axs[0].set_ylabel('speed')
        self.axs[1].set_ylabel('acc')
        self.axs[2].set_ylabel('steer')
        self.axs[3].set_ylabel('reward')
        self.axs[4].set_ylabel('heading')
        if current_step > 40:
            self.text.set_text('Using method is: ' + self.rl_method)
            self.text.set_position((current_step-25, 25))
        plt.pause(0.001)

class Epistemic_Uncertainty_Data_Displayer(object):
    def __init__(self,
                 ):
        self.fig, self.axs = plt.subplots(3, 1, figsize=(6,6))  # 创建5行1列的子图布局
        self.x_data = []
        self.y_data = [[] for _ in range(3)]

        self.axs[0].set_ylim(-1.05, 1.05)
        self.axs[1].set_ylim(-1.05, 1.05)
        self.axs[2].set_ylim(-1.05, 1.05)

        self.line1, = self.axs[0].plot(self.x_data, self.y_data[0], color='blue', label='Left_Epistemic_Uncertainty')
        self.line2, = self.axs[1].plot(self.x_data, self.y_data[1], color='red', label='IDLE_Epistemic_Uncertainty')
        self.line3, = self.axs[2].plot(self.x_data, self.y_data[2], color='yellow', label='Right_Epistemic_Uncertainty')

        self.text = self.axs[0].text(3, 0, '', fontsize=10, ha='center')
        # plt.pause(0.1)

    def epistemic_uncertainty_display(self, current_step, epistemic_uncertainty):
        epistemic_uncertainty_mean = np.mean(epistemic_uncertainty)
        # 移除最早添加的元素
        while len(self.x_data) > 100:
            self.x_data.pop(0)
        for i in range(len(self.y_data)):
            while len(self.y_data[i]) > 100:
                self.y_data[i].pop(0)

        left_epi = epistemic_uncertainty[0]
        IDLE_epi = epistemic_uncertainty[1]
        right_epi = epistemic_uncertainty[2]
        data = [left_epi, IDLE_epi, right_epi]
        # 添加新数据点
        self.x_data.append(current_step)
        for i in range(len(self.y_data)):
            self.y_data[i].append(data[i])
        # 更新线条数据
        self.line1.set_data(self.x_data, self.y_data[0])
        self.line2.set_data(self.x_data, self.y_data[1])
        self.line3.set_data(self.x_data, self.y_data[2])

        # 动态调整x轴范围
        step_delta = 1
        for self.ax in self.axs:
            self.ax.set_xlim(max(0, current_step - 50*step_delta), max(50*step_delta, current_step))
        self.axs[0].set_ylabel('Left_Epistemic_Uncertainty')
        self.axs[1].set_ylabel('IDLE_Epistemic_Uncertainty')
        self.axs[2].set_ylabel('Right_Epistemic_Uncertainty')
        if current_step > 40:
            self.text.set_text('Epistemic uncertainty of three actions' +
                               '\nepistemic_uncertainty_mean is ' + str(epistemic_uncertainty_mean))
            self.text.set_position((current_step-25*step_delta, 25))
        plt.pause(0.001)