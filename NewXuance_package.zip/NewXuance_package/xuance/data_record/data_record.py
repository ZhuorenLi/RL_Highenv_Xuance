import numpy as np
import matplotlib.pyplot as plt
import math
from highway_env import utils
import copy
import os
import pandas as pd


class Data_Recorder(object):
    def __init__(self,
                 env = None,
                 data_record_dir = None,
                 highd_test_epsoides=None
                 ):
        self.env = env
        self.data_record_dir = data_record_dir
            
        # data of every steps
        self.car_speed_record = []
        self.car_heading_record = []
        self.car_acc_record = []
        self.car_steer_record = []
        self.car_reward_record = []
        self.one_episode_data = None
        
        # data of every episodes
        self.all_episodes = []
        self.all_length = []
        self.all_episode_score = []
        self.all_episode_safety_score = []
        self.all_is_collision = []
        self.all_average_speed = []
        self.all_average_acc = []
        self.all_record_data = None
        
        # highd
        self.highd_test_epsoides = highd_test_epsoides

    def save_data_every_step(self, reward=None, current_episode=None, is_save_to_csv=False, is_collision=False):

        if is_save_to_csv:
            os.makedirs(self.data_record_dir, exist_ok=True) 
            # 在单个文件中以step为单位存储数据，存储为多个文件
            if self.highd_test_epsoides is None:
                self.one_episode_data.to_csv( self.data_record_dir + '/' + str(current_episode) + '.csv', index=False, sep=',')
            else:
                self.one_episode_data.to_csv( self.data_record_dir + '/' + str(self.highd_test_epsoides) + '.csv', index=False, sep=',')

            self.car_speed_record = []
            self.car_heading_record = []
            self.car_acc_record = []
            self.car_steer_record = []
            self.car_reward_record = []
            return 

        self.car_speed_record.append(self.env.vehicle.speed)
        self.car_heading_record.append(self.env.vehicle.heading)
        self.car_acc_record.append(self.env.vehicle.action["acceleration"])
        self.car_steer_record.append(self.env.vehicle.action["steering"])
        self.car_reward_record.append(reward)
        self.one_episode_data = pd.DataFrame({'car_speed_record': self.car_speed_record,
                                              'car_heading_record': self.car_heading_record,
                                              'car_acc_record': self.car_acc_record,
                                              'car_steer_record': self.car_steer_record,
                                              'reward': self.car_reward_record
                                              })

    def save_data_every_episode(self, infos=None, current_episode=None, is_save_to_csv=False):

        if is_save_to_csv:
            self.all_record_data = pd.DataFrame({'episode': self.all_episodes,
                                            'all_length': self.all_length,
                                            'all_episode_score': self.all_episode_score,
                                            'all_episode_safety_score': self.all_episode_safety_score,
                                            'all_is_collision': self.all_is_collision,
                                            'all_average_speed': self.all_average_speed,
                                            'all_average_acc': self.all_average_acc,
                                            })
            if self.highd_test_epsoides is None or self.highd_test_epsoides == 0:
                self.all_record_data.to_csv(self.data_record_dir + '/' + 'all_record_data.csv', index=False, sep=',')  # 存储数据
            else:
                self.all_record_data.to_csv(self.data_record_dir + '/' + 'all_record_data.csv', index=False, sep=',', 
                                            mode='a', header=False)  # 存储数据

            self.all_episodes = []
            self.all_length = []
            self.all_episode_score = []
            self.all_episode_safety_score = []
            self.all_is_collision = []
            self.all_average_speed = []
            self.all_average_acc = []
            return  
        
        self.all_episodes.append(current_episode)
        self.all_length.append(infos['episode_step'])
        self.all_episode_score.append(infos["episode_score"])
        self.all_episode_safety_score.append(infos["episode_safety_score"])
        self.all_is_collision.append(int(infos["crashed"]))
        self.all_average_speed.append(sum(self.car_speed_record) / (len(self.car_speed_record)))
        self.all_average_acc.append(sum(abs(x) for x in self.car_acc_record) / len(self.car_acc_record))


        
